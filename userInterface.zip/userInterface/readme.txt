Tarayıcı senkronizasyonunu ve watchı başlatma: grunt

Projeyi build etme: grunt b-prj

Build edilmiş projeyi silme: d-bprj